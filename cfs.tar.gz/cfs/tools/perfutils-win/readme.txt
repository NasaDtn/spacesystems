The file named SoftwareTimingAnalyzer.msi is an installation file for the gui application.
This installation file is designed to work only with windows based machines.
To install the Software Timing Analyzer gui and supporting documents, just double click on the installation file.
