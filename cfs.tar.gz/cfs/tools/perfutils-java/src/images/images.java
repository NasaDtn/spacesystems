/* CFS Performance Monitor
 * Dummy class for images folder
 */
package images;

public class images
{

}
