/* CFS Performance Monitor
 * Dummy class for docs folder
 */
package docs;

public class docs
{

}
