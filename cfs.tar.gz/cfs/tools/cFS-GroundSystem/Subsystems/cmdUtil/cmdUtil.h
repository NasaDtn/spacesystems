int SendUdp(char *hostname, char *portNum, char *packetData, int packetSize);

